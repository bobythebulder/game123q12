# Party Panic: Meteor Dodge

A beginner-friendly browser multiplayer game. Players create a party, share a short code, and join from different devices. Only the party host can start the round.

## Run it on your computer

1. Install Node.js LTS from https://nodejs.org/
2. Extract this ZIP file.
3. Open a terminal/command prompt inside the extracted `party_panic_multiplayer` folder.
4. Run `npm install`
5. Run `npm start`
6. Open http://localhost:3000 in your browser.

To test locally, open another browser tab and join using the party code.

## Let friends join online

Deploy the folder as a **Web Service** on a Node.js hosting provider such as Render:
- Build command: `npm install`
- Start command: `npm start`
- The app listens on the hosting provider's `PORT` environment variable.
- Once deployed, share the public HTTPS URL with friends.

For GitHub, upload the extracted files (including the `public` folder) to a repository. Do not upload `node_modules`.

## How to play

- Create a party and send the 6-character code to friends.
- The host presses **START GAME** when ready.
- Move with WASD or arrow keys (or on-screen arrows on touch devices).
- Dodge meteors for 60 seconds. Players hit by meteors are out.
- The host can start another round after the results screen.

Party size: up to 8 players. This is a small starter project, so keep the server running while playing.

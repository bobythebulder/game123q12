const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;

app.use(express.static("public"));

const parties = new Map();
const COLORS = ["#65e4ff", "#ff6bcb", "#ffe66d", "#a78bfa", "#7cf29a", "#ff9f68"];

function code() {
  return crypto.randomBytes(3).toString("hex").toUpperCase();
}
function cleanName(name) {
  return String(name || "Player").trim().replace(/[<>]/g, "").slice(0, 16) || "Player";
}
function publicParty(p) {
  return {
    code: p.code,
    hostId: p.hostId,
    status: p.status,
    players: [...p.players.values()].map(x => ({
      id: x.id, name: x.name, color: x.color,
      x: x.x, y: x.y, score: x.score, alive: x.alive
    }))
  };
}
function sendParty(p) {
  io.to(p.code).emit("party:update", publicParty(p));
}
function getPartyFor(socket) {
  return socket.data.partyCode ? parties.get(socket.data.partyCode) : null;
}
function leaveParty(socket) {
  const p = getPartyFor(socket);
  if (!p) return;
  p.players.delete(socket.id);
  socket.leave(p.code);
  socket.data.partyCode = null;
  if (!p.players.size) {
    clearInterval(p.timer);
    parties.delete(p.code);
    return;
  }
  if (p.hostId === socket.id) {
    p.hostId = p.players.keys().next().value;
    io.to(p.code).emit("notice", "The host left. A new host was chosen.");
  }
  if (p.status === "playing" && [...p.players.values()].every(pl => !pl.alive)) {
    p.status = "results";
  }
  sendParty(p);
}

io.on("connection", socket => {
  socket.on("party:create", ({ name } = {}, reply = () => {}) => {
    leaveParty(socket);
    let id = code();
    while (parties.has(id)) id = code();
    const player = {
      id: socket.id, name: cleanName(name), color: COLORS[Math.floor(Math.random()*COLORS.length)],
      x: 0, y: 0, score: 0, alive: true
    };
    const p = { code: id, hostId: socket.id, players: new Map([[socket.id, player]]), status: "lobby", endsAt: 0, timer: null };
    parties.set(id, p);
    socket.join(id);
    socket.data.partyCode = id;
    reply({ ok: true, code: id });
    sendParty(p);
  });

  socket.on("party:join", ({ name, code: requested } = {}, reply = () => {}) => {
    const id = String(requested || "").trim().toUpperCase();
    const p = parties.get(id);
    if (!p) return reply({ ok: false, error: "Party code not found. Check the code and try again." });
    if (p.status !== "lobby") return reply({ ok: false, error: "That game has already started." });
    if (p.players.size >= 8) return reply({ ok: false, error: "That party is full (8 players max)." });
    leaveParty(socket);
    const player = {
      id: socket.id, name: cleanName(name), color: COLORS[Math.floor(Math.random()*COLORS.length)],
      x: 0, y: 0, score: 0, alive: true
    };
    p.players.set(socket.id, player);
    socket.join(id);
    socket.data.partyCode = id;
    reply({ ok: true, code: id });
    sendParty(p);
  });

  socket.on("game:start", () => {
    const p = getPartyFor(socket);
    if (!p || p.hostId !== socket.id || p.status !== "lobby") return;
    p.status = "playing";
    p.endsAt = Date.now() + 60000;
    let idx = 0;
    for (const pl of p.players.values()) {
      pl.x = 100 + (idx % 4) * 150;
      pl.y = 100 + Math.floor(idx / 4) * 170;
      pl.score = 0; pl.alive = true; idx++;
    }
    p.meteors = [];
    clearInterval(p.timer);
    p.timer = setInterval(() => {
      if (p.status !== "playing") return clearInterval(p.timer);
      const now = Date.now();
      if (Math.random() < 0.65) {
        p.meteors.push({ id: crypto.randomBytes(4).toString("hex"), x: 35 + Math.random()*530, y: -35, speed: 2.2 + Math.random()*2.5, r: 10 + Math.random()*12 });
      }
      p.meteors = p.meteors.filter(m => m.y < 440);
      for (const m of p.meteors) m.y += m.speed;
      for (const pl of p.players.values()) {
        if (!pl.alive) continue;
        for (const m of p.meteors) {
          if (Math.hypot(pl.x - m.x, pl.y - m.y) < m.r + 13) {
            pl.alive = false;
            break;
          }
        }
      }
      if (now >= p.endsAt || [...p.players.values()].every(pl => !pl.alive)) {
        p.status = "results";
        clearInterval(p.timer);
      }
      io.to(p.code).emit("game:state", {
        status: p.status, endsAt: p.endsAt, serverNow: now,
        players: [...p.players.values()].map(pl => ({ id: pl.id, name: pl.name, color: pl.color, x: pl.x, y: pl.y, score: pl.score, alive: pl.alive })),
        meteors: p.meteors
      });
      sendParty(p);
    }, 50);
    sendParty(p);
  });

  socket.on("game:move", ({ dx, dy } = {}) => {
    const p = getPartyFor(socket);
    if (!p || p.status !== "playing") return;
    const pl = p.players.get(socket.id);
    if (!pl || !pl.alive) return;
    const len = Math.hypot(Number(dx)||0, Number(dy)||0) || 1;
    pl.x = Math.max(18, Math.min(582, pl.x + ((Number(dx)||0)/len)*5));
    pl.y = Math.max(18, Math.min(422, pl.y + ((Number(dy)||0)/len)*5));
  });

  socket.on("game:play-again", () => {
    const p = getPartyFor(socket);
    if (!p || p.hostId !== socket.id || p.status !== "results") return;
    p.status = "lobby";
    clearInterval(p.timer);
    sendParty(p);
  });

  socket.on("party:leave", () => {
    leaveParty(socket);
    socket.emit("party:left");
  });
  socket.on("disconnect", () => leaveParty(socket));
});

server.listen(PORT, () => console.log(`Party Panic is running on port ${PORT}`));
